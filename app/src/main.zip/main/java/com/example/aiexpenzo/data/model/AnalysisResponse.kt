package com.example.aiexpenzo.data.model

class AnalysisResponse(
    val analysis: List<String>
)