package com.example.aiexpenzo.data.model

data class AppGuideContent(
    val title: String,
    val description: String
)