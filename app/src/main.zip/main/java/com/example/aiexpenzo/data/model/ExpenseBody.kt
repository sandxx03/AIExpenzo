package com.example.aiexpenzo.data.model

data class ExpenseBody(
    val amount: Double,
    val category: String,
    val description: String =""
)