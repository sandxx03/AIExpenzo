package com.example.aiexpenzo.data.constants

val PAYMENT_METHODS = listOf(
    "Cash",
    "Credit Card",
    "Debit Card",
    "e-Wallet/QR Pay",
    "Cheque"

)