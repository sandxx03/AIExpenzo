package com.example.aiexpenzo.data.constants

val EXPENSE_CATEGORIES = listOf(
    "Housing & Utilities",
    "Food",
    "Transportation",
    "Health & Insurance",
    "Entertainment & Subscriptions",
    "Shopping",
    "Debt Repayment",
    "Savings & Investments",
    "Other"
)