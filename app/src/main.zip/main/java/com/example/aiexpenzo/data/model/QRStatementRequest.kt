package com.example.aiexpenzo.data.model

data class QRStatementRequest (
    val statement: String
)