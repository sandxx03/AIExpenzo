package com.example.aiexpenzo.data.model

data class CategorySpend (
    val title: String,
    val amount: Float,
    val date: String
)